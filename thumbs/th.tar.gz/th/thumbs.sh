#!/bin/sh

usage ()
{
	echo "$0 <img dir> <thumb dir>"
	echo "entrambe devono esistere"
	exit
}

[ "x$1" == "x" ] && usage 
[ "x$2" == "x" ] && usage 
[ -d $1 ] || usage 
[ -d $2 ] || usage

THUMBS=$2/mini
HTML=$2/html
[ -d $THUMBS ] || mkdir $THUMBS
[ -d $HTML ] || mkdir $HTML 

> $2/index_gr.lst
> $2/index.lst

for i in $1/*.JPG
do
	BASE=`basename $i .JPG | sed -e 's/-/_/g'`
        # djpeg -scale 1/8 $i | cjpeg -outfile mini/th_$i ;
        #djpeg -scale 1/8 $i | cjpeg -grayscale -outfile mini/th_gr_$i ;
	[ $i -nt $THUMBS/th_$BASE ] && convert -scale 240x180  $i $THUMBS/th_$BASE
	[ $i -nt $THUMBS/th_gr_$BASE ] && convert -scale 240x180 -blur 3x10 $i $THUMBS/th_gr_$BASE
	# echo "<td>"
        echo "<a href=\"$HTML/$BASE.html\"
                onMouseOver=\"WM_imageSwap( 'x$BASE', '$THUMBS/th_$BASE' );\"
                onMouseOut=\"WM_imageSwap( 'x$BASE', '$THUMBS/th_gr_$BASE' );\">
<img height=100 name="x$BASE" border=0 src=\"$THUMBS/th_gr_$BASE\"></a>" >> $2/index_gr.lst
        echo "<a href=\"$BASE.JPG\"><img border=0 src=\"$THUMBS/th_$BASE\"></a>" >> $2/index.lst

# Image::Info here
cat > $HTML/$BASE.html <<EOF
<html>
<head></head>
<body>
<center><img src="../../$i" width=640></center>
</body>
</html>

EOF

done

cat head.inc $2/index_gr.lst tail.inc > index.shtml
